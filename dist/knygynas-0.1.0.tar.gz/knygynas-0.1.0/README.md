
Viskas veikia.
Pagrindinės funkcijos:
Knygyno
    Įtraukti knygą
    Pašalinti knygą 
    Paskolinti knygą
    Ieškoti knygos
    Peržiūrėti skaitytojus
    Išsaugoti duomenis į failus
    Grąžinti paskolintas knygas
    Peržiūrėti visas knygas
    Peržiūrėti skaitytojus su skolomis ir neleidzia skolininkams pasimti naujos knygos
    Ištrinti skaitytojus

Atitinka visas instrukcijas ir būtinas sąlygas.
+Bonus naudota poetry+ dar kelias ekstra funkcijas padariau.

Šios funkcijos padeda valdyti bibliotekos veiklą efektyviau.